export default class Anuncio{
    constructor(id, title, transaction, description, price){
        this.id = id;
        this.title = title;
        this.transaction = transaction;
        this.description = description;
        this.price = price;
    }
}